from zrb import Group

noto_todo_group = Group(name="todo", description="To do")
