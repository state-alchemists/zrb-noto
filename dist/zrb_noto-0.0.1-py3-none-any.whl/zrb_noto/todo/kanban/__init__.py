from .kanban import show_kanban

assert show_kanban
