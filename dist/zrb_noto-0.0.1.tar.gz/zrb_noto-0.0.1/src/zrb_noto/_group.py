from zrb import Group

noto_group = Group(name="noto", description="Noto management")
noto_wiki_group = Group(name="wiki", description="Noto wiki")
