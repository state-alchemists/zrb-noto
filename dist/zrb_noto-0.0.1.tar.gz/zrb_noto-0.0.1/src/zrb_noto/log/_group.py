from zrb import Group

noto_log_group = Group(name="log", description="Task logging")
