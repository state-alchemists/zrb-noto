from ._group import noto_log_group
from .add import add_log
from .list import list_log

assert noto_log_group
assert add_log
assert list_log
